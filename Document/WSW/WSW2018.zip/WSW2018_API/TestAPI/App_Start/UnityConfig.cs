using System.Web.Mvc;
using Microsoft.Practices.Unity;
using Unity.Mvc5;
using DataAccess.Repositories;
using DataAccess.Infrastructure;
using DataAccess.UnitOfWork;
using DataAccess.Services;
using Unity;

namespace EcommerceAPI
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			

            #region register all your components with the container here
            // it is NOT necessary to register your controllers
            //container.RegisterType<IEmailService, EmailService>();
            //container.RegisterType<ICacheProvider, DefautCacheProvider>();

            //container.RegisterType<ICatalogueService, CatalogueService>();
            //container.RegisterType<IClientService, ClientService>();
            //container.RegisterType<IParmalatService, ParmalatService>();
            //container.RegisterType<IEmployeeService, EmployeeService>();

            //container.RegisterType<ICatalogueRepository, CatalogueRepository>();
            //container.RegisterType<IClientRepository, ClientRepository>(new InjectionConstructor("sa", "tpf@75high", "10.0.2.44"));
            //container.RegisterType<IParmalatRepository, ParmalatRepository>(new InjectionConstructor( "sa", "tpf@75high", "10.0.2.44"));
            //container.RegisterType<IEmployeeRepository, EmployeeRepository>();

            var unityContainer = new UnityContainer();
            // Register IGame so when dependecy is detected
            // it provides a TrivialPursuit instance       

            unityContainer.RegisterType<IBlogRepository, BlogRepository>();
            unityContainer.RegisterType<IClubRepository, ClubRepository>();
            unityContainer.RegisterType<IMemberRepository, MemberRepository>();

            unityContainer.RegisterType<IConnectionFactory, ConnectionFactory>();
            unityContainer.RegisterType<IUnitOfWork, UnitOfWork>();
            unityContainer.RegisterType<IMemberService, MemberService>();
            unityContainer.RegisterType<IBlogService, BlogService>();



            //container.Register<IParmalatRepository>(new InjectionFactory(c =>  return new ParmalatRepository(  "server name", "port", "username", "password")));

            #endregion

            DependencyResolver.SetResolver(new UnityDependencyResolver(unityContainer));
        }
    }
}