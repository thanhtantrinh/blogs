﻿using DataAccess.Infrastructure;
using DataAccess.Repositories;
using DataAccess.Services;
using DataAccess.UnitOfWork;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Unity;

namespace EcommerceAPI.Helpers
{
    public class Helper
    {
    }
    /// <summary>
    /// Load All information of Club
    /// </summary>
    public static class ClubConfiguration
    {
        public static IMemberService _memberService;
        /// <summary>
        /// Club Id
        /// </summary>
        public static int Club_Id;
        /// <summary>
        /// Email Club or Email Site
        /// </summary>
        public static string Club_Email;
        /// <summary>
        /// Email Admin to manage club
        /// </summary>
        public static string Club_Admin_Email;
        /// <summary>
        /// Name Club
        /// </summary>
        public static string Club_Name;
        /// <summary>
        /// Site name of Club
        /// </summary>
        public static string Api_Domain;
        public static string Club_Phone;
        public static string Club_Logo;
        public static string XsrfKey;
        /// <summary>
        /// To Maintenance
        /// </summary>
        public static bool isMaintenance;
        /// <summary>
        /// This API is development
        /// </summary>
        public static bool isDevelopment;
        /// <summary>
        /// This is connection string 
        /// </summary>
        public static string connectionString;
        public static void StoreSettings()
        {

            LoadSettings();
        }

        private static void LoadSettings()
        {
            XsrfKey = ConfigurationManager.AppSettings["XSRFKEY"];
            Int32.TryParse(ConfigurationManager.AppSettings["club_id"], out Club_Id);
            Club_Admin_Email = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["admin_email"]) ? "ecom-log@tpfvietnam.vn" : ConfigurationManager.AppSettings["admin_email"];
            Club_Email = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["club_email"]) ? "ecom-log@tpfvietnam.vn" : ConfigurationManager.AppSettings["club_email"];
            Api_Domain = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["api_domain"]) ? "http://wswapi.previews.tpf.com.au" : ConfigurationManager.AppSettings["api_domain"];
            isMaintenance = !String.IsNullOrEmpty(ConfigurationManager.AppSettings["ismaintenance"]) && ConfigurationManager.AppSettings["ismaintenance"].ToString().ToLower() == "true" ? true : false;
            isDevelopment = !String.IsNullOrEmpty(ConfigurationManager.AppSettings["isdevelopment"]) && ConfigurationManager.AppSettings["isdevelopment"].ToString().ToLower() == "true" ? true : false;
            connectionString = String.IsNullOrEmpty(ConfigurationManager.ConnectionStrings["APIAppCon"].ConnectionString) ? "" : ConfigurationManager.ConnectionStrings["APIAppCon"].ConnectionString;

            try
            {
                //// Declare a Unity Container
                var unityContainer = new UnityContainer();
                //// Register IGame so when dependecy is detected
                //// it provides a TrivialPursuit instance       

                unityContainer.RegisterType<IBlogRepository, BlogRepository>();
                unityContainer.RegisterType<IClubRepository, ClubRepository>();
                unityContainer.RegisterType<IMemberRepository, MemberRepository>();

                unityContainer.RegisterType<IConnectionFactory, ConnectionFactory>();
                unityContainer.RegisterType<IUnitOfWork, UnitOfWork>();
                unityContainer.RegisterType<IMemberService, MemberService>();
                unityContainer.RegisterType<IBlogService, BlogService>();

                //// Instance a Table class object through Unity
                _memberService = unityContainer.Resolve<MemberService>();               

                var club = _memberService.GetClub(Club_Id);

                if (club != null)
                {
                    Club_Name = club.Name;
                }

            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}