﻿using System;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;

namespace EcommerceAPI.Models
{
    public class EmailService : IIdentityMessageService
    {
        private const string _mailserver = "sendmail.tpf.com.au";
        private const string _mailFrom = "notification@tpf.com.au";

        #region methods
        public EmailService()
        {

        }
        public Task SendAsync(IdentityMessage message)
        {
            // Plug in your email service here to send an email.
            MailAddress EmailTo = new MailAddress(message.Destination);
            MailAddress EmailFrom = new MailAddress(_mailFrom, "TPF Group");
            var task = SendEmailAsync(EmailTo, EmailFrom, message.Subject, message.Body);
            return task;
        }

        public static void SendEmail(string to, string from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to, subject, body);
                message.IsBodyHtml = true;
                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }
                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                SmtpClient client = new SmtpClient(_mailserver);
                client.Send(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }

        public static async Task SendEmailAsync(MailAddress to, MailAddress from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to);
                message.IsBodyHtml = true;
                message.From = from;
                message.Subject = subject;
                message.Body = body;

                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }

                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                SmtpClient client = new SmtpClient(_mailserver);
                await client.SendMailAsync(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }
    }
    #endregion

    public class SmsService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // Plug in your sms service here to send a text message.
            return Task.FromResult(0);
        }
    }
}