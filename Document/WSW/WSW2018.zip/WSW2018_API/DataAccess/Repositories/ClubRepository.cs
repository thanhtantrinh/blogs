﻿using Dapper;
using DataAccess.EntitiesDataBase;
using DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public class ClubRepository : GenericRepository<Club>, IClubRepository
    {
        IConnectionFactory _connectionFactory;        

        public ClubRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;                  
        }

        public Club GetClub(int ClubId)
        {
            var result =  DbContext.Clubs.FirstOrDefault(f=>f.ID==ClubId);

            return result;
        }

        public async Task<Club> GetClubAsync(int clubId=0)
        {
            var query = "usp_GetAllBlogPostByPageIndex";
            var param = new DynamicParameters();
            param.Add("@ClubId", clubId);
            var list = await SqlMapper.QueryAsync<Club>(_connectionFactory.GetConnection, query, param, commandType: CommandType.StoredProcedure);
            return list.FirstOrDefault();
        }
        
    }
}
