﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.ViewModel
{
    public class ResetPasswordRequest
    {
        public string Username { get; set; }
        public string TokenLink { get; set; }
    }
}
