﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Constants
{
    /// <summary>
    /// Status Group
    /// </summary>
    public enum SpecialRequirementType
    {
        None,
        Attachment,
        Other
    }
    /// <summary>
    /// Status Group
    /// </summary>
    public enum GroupStatus
    {
        Pending,
        Submited
    }
    /// <summary>
    /// Type Group
    /// </summary>
    public enum GroupType
    {
        Single,
        Group
    }
}
