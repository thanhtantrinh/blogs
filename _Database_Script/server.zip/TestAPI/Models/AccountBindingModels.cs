﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAccess;
using Newtonsoft.Json;

namespace EcommerceAPI.Models
{
    // Models used as parameters to AccountController actions.
    /// <summary>
    /// AddExternalLoginBindingModel to support to validate the data
    /// </summary>
    public class AddExternalLoginBindingModel
    {
        /// <summary>
        /// this is External access token
        /// </summary>
        [Required]
        [Display(Name = "External access token")]
        public string ExternalAccessToken { get; set; }
    }
    /// <summary>
    /// LoginViewModel to support to validate the data
    /// </summary>
    public class LoginViewModel
    {
        /// <summary>
        /// This is Member number
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "MemberId")]
        public string MemberID { get; set; }

        /// <summary>
        /// This is password of member
        /// </summary>
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        /// <summary>
        /// To Remember Password on API not used
        /// </summary>
        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class ChangePasswordBindingModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class RegisterBindingModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "MemberId")]
        public string MemberId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class RegisterExternalBindingModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }

    public class RemoveLoginBindingModel
    {
        [Required]
        [Display(Name = "Login provider")]
        public string LoginProvider { get; set; }

        [Required]
        [Display(Name = "Provider key")]
        public string ProviderKey { get; set; }
    }
    /// <summary>
    /// Password Binding Model to support to validate the data
    /// </summary>
    public class SetPasswordBindingModel
    {
        /// <summary>
        /// New password
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }
        /// <summary>
        /// Confirm new password
        /// </summary>
        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }
    /// <summary>
    /// Forgot Password Binding Model to support to validate the data
    /// </summary>
    public class ForgotPasswordBindingModel
    {
        /// <summary>
        /// Email of member to need to reset password
        /// </summary>
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
    /// <summary>
    /// Reset Password Binding Model to support to validate the data
    /// </summary>
    public class ResetPasswordBindingModel
    {
        /// <summary>
        /// Member Id and User Id
        /// </summary>
        [Required]
        [Display(Name = "Id")]
        public long UserId { get; set; }
        /// <summary>
        /// This is member number or Username
        /// </summary>        
        [Display(Name = "MemberId")]
        public string MemberId { get; set; }
        /// <summary>
        /// Password of Member
        /// </summary>
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }
        /// <summary>
        /// Confirm Password of Member
        /// </summary>

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
        /// <summary>
        /// This is token will be send in your email
        /// </summary>
        [Required]
        [Display(Name = "Code")]
        public string Code { get; set; }
    }
    /// <summary>
    /// Member Group Binding Model to store member in group
    /// </summary>
    public class MemberGroupBindingModel
    {
        /// <summary>
        /// List member in the group
        /// </summary>
        public List<MemberGroupDetailBindingModel> MemberInGroup { get; set; }
        /// <summary>
        /// Information of the group
        /// </summary>
        public GroupBindingModel GroupDetail { get; set; }
    }
}
