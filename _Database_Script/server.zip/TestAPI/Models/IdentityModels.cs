﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System.Data.Entity;
using EcommerceAPI.Models;
using System;

namespace EcommerceAPI.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser<long, MemberLogin, MemberRole, MemberClaim>
    {
        #region properties
        public string ActivationToken { get; set; }
        public string PasswordAnswer { get; set; }
        public string PasswordQuestion { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Member is of Group
        /// </summary>
        public int ClubID { get; set; }
        #endregion
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser,long> manager, string authenticationType)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, authenticationType);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, RoleList, long, MemberLogin, MemberRole, MemberClaim>
    {
        public ApplicationDbContext()
            : base("WSWContext")
        {
        }
        
        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Map Entities to their tables.
            modelBuilder.Entity<ApplicationUser>().ToTable("WSW_Member");
            modelBuilder.Entity<RoleList>().ToTable("WSW_Role");
            modelBuilder.Entity<MemberClaim>().ToTable("WSW_MemberClaim");
            modelBuilder.Entity<MemberLogin>().ToTable("WSW_MemberLogin");
            modelBuilder.Entity<MemberRole>().ToTable("WSW_MemberRole");

            // Set AutoIncrement-Properties
            modelBuilder.Entity<ApplicationUser>().Property(r => r.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            modelBuilder.Entity<MemberClaim>().Property(r => r.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            modelBuilder.Entity<MemberRole>().Property(r => r.RoleId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            // Override some column mappings that do not match our default            
            modelBuilder.Entity<ApplicationUser>().Property(r => r.Id).HasColumnName("ID");
            modelBuilder.Entity<ApplicationUser>().Property(r => r.UserName).HasColumnName("MemberID");
            modelBuilder.Entity<ApplicationUser>().Property(r => r.PasswordHash).HasColumnName("Password");
            modelBuilder.Entity<ApplicationUser>().Property(r => r.AccessFailedCount).HasColumnName("AccessFailedCount");
            modelBuilder.Entity<ApplicationUser>().Property(r => r.UpdatedDate).HasColumnName("UpdatedDate");
            //modelBuilder.Entity<ApplicationUser>().Property(r => r.).HasColumnName("UpdatedDate");

            modelBuilder.Entity<MemberClaim>().Property(r => r.UserId).HasColumnName("MemberId");
            modelBuilder.Entity<MemberRole>().Property(r => r.UserId).HasColumnName("MemberId");
            modelBuilder.Entity<MemberLogin>().Property(r => r.UserId).HasColumnName("MemberId");
        }
    }
}