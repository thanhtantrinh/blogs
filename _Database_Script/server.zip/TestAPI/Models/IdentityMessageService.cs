﻿using System;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using EcommerceAPI.Helpers;

namespace EcommerceAPI.Models
{
    /// <summary>
    /// Email Service of 
    /// </summary>
    public class EmailService : IIdentityMessageService
    {
        #region const
        private const string _mailserver = "sendmail.tpf.com.au";
        private const string _mailFrom = "notification@tpf.com.au";
        #endregion

        #region methods
        public EmailService()
        {

        }
        /// <summary>
        /// Send Async
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public async Task SendAsync(IdentityMessage message)
        {
            // Plug in your email service here to send an email.
            MailAddress EmailTo = new MailAddress(message.Destination);
            MailAddress EmailFrom = new MailAddress(ClubConfiguration.Club_Email, ClubConfiguration.Club_Name);
            await SendEmailAsync(EmailTo, EmailFrom, message.Subject, message.Body, null, new string[] { ClubConfiguration.Club_Admin_Email });            
        }
        /// <summary>
        /// Send Email Async
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        /// <returns></returns>
        public static async Task SendEmailAsync(MailAddress to, MailAddress from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to);
                message.IsBodyHtml = true;
                message.From = from;
                message.Subject = subject;
                message.Body = body;

                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }

                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                SmtpClient client = new SmtpClient(_mailserver);
                await client.SendMailAsync(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }
    }
    #endregion

    public class SmsService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // Plug in your sms service here to send a text message.
            return Task.FromResult(0);
        }
    }
}