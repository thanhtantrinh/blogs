﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace EcommerceAPI.Models
{
    public class RoleList : IdentityRole<long, MemberRole>
    {

    }

    public class MemberRole : IdentityUserRole<long>
    {
    }
    public class MemberLogin : IdentityUserLogin<long>
    {

    }
    public class MemberClaim : IdentityUserClaim<long>
    {

    }


}