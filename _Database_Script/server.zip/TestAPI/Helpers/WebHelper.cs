﻿using EcommerceAPI.Helpers;
using EcommerceAPI.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace System.Web.Mvc
{
    public static class HTMLExtensions
    {
        #region Render View
        public static string RenderViewToString(Controller controller, string viewName, string masterViewName, object model)
        {
            if (string.IsNullOrEmpty(viewName))
                viewName = controller.ControllerContext.RouteData.GetRequiredString("action");

            controller.ViewData.Model = model;
            using (StringWriter sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindView(controller.ControllerContext, viewName, masterViewName);
                ViewContext viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);

                return sw.ToString();
            }
        }
        public static string RenderPartialViewToString(Controller controller, string viewName, object model)
        {
            if (string.IsNullOrEmpty(viewName))
                viewName = controller.ControllerContext.RouteData.GetRequiredString("action");

            controller.ViewData.Model = model;
            using (StringWriter sw = new StringWriter())
            {
                ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(controller.ControllerContext, viewName);
                ViewContext viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
                viewResult.View.Render(viewContext, sw);

                return sw.ToString();
            }
        }
        #endregion
        /// <summary>
        /// Generates a fully qualified URL to an action method by using
        /// the specified action name, controller name and route values.
        /// </summary>
        /// <param name="url">The URL helper.</param>
        /// <param name="actionName">The name of the action method.</param>
        /// <param name="controllerName">The name of the controller.</param>
        /// <param name="routeValues">The route values.</param>
        /// <returns>The absolute URL.</returns>
        public static string AbsoluteAction(this UrlHelper url, string actionName, string controllerName, object routeValues = null)
        {
            string scheme = url.RequestContext.HttpContext.Request.Url.Scheme;

            return url.Action(actionName, controllerName, routeValues, scheme);
        }
        /// <summary>
        /// Get full link of a image on the sever
        /// </summary>
        /// <param name="url"></param>
        /// <param name="imagePath"></param>
        /// <param name="isContentRoot"></param>
        /// <returns></returns>
        public static string Image(this UrlHelper url, string imagePath, bool isContentRoot = false)
        {
            string folderPath = !isContentRoot ? APIResource.Dir_Images : APIResource.Dir_Content_Image;

            if (ClubConfiguration.isDevelopment)
            {
                var baseurl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                folderPath = baseurl + folderPath;
            }
            else
            {
                folderPath = ClubConfiguration.Club_Domain + folderPath;
            }
            return url.Content(string.Format(folderPath, imagePath));
        }
    }
}