﻿using DataAccess.Entities;
using DataAccess.Infrastructure;
using DataAccess.Repositories;
using DataAccess.Services;
using DataAccess.UnitOfWork;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using Unity;

namespace EcommerceAPI.Helpers
{
    public static class Helper
    {
        //public static string baseUrl = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
        

    }
    /// <summary>
    /// Load All information of Club
    /// </summary>
    public static class ClubConfiguration
    {
        /// <summary>
        /// 
        /// </summary>
        public static IMemberService _memberService;
        /// <summary>
        /// XSRF Key of Password
        /// </summary>
        public static string XsrfKey;
        /// <summary>
        /// Public Key of club
        /// </summary>
        public static string PublicKey;
        /// <summary>
        /// Maximum Member in  a Group
        /// </summary>
        public static int MaxMember;
        /// <summary>
        /// Club Id
        /// </summary>
        public static int Club_Id;
        /// <summary>
        /// Email Club or Email Site
        /// </summary>
        public static string Club_Email;
        /// <summary>
        /// Email Admin to manage club
        /// </summary>
        public static string Club_Admin_Email;
        /// <summary>
        /// Name Club
        /// </summary>
        public static string Club_Name;
        /// <summary>
        /// Domain for API
        /// </summary>
        public static string Api_Domain;
        /// <summary>
        /// Domain website for Club member
        /// </summary>
        public static string Club_Domain;
        /// <summary>
        /// Phone support
        /// </summary>
        public static string Club_Phone;
        /// <summary>
        /// Logo of Club
        /// </summary>
        public static string Club_Logo;
        /// <summary>
        /// Logo of Club
        /// </summary>
        public static string LogoHeaderEmail;
        /// <summary>
        /// To Maintenance
        /// </summary>
        public static bool isMaintenance;
        /// <summary>
        /// This API is development
        /// </summary>
        public static bool isDevelopment;
        /// <summary>
        /// This is connection string 
        /// </summary>
        public static string connectionString;
        /// <summary>
        /// Get infomation of Store
        /// </summary>
        public static void StoreSettings()
        {
            //// Declare a Unity Container
            var unityContainer = new UnityContainer();
            //// Register IGame so when dependecy is detected
            
            unityContainer.RegisterType<IBlogRepository, BlogRepository>();
            unityContainer.RegisterType<IClubRepository, ClubRepository>();
            unityContainer.RegisterType<IMemberRepository, MemberRepository>();
            unityContainer.RegisterType<ISeatingRepository, SeatingRepository>();
            unityContainer.RegisterType<ISpecialRequirementRepository, SpecialRequirementRepository>();

            unityContainer.RegisterType<IConnectionFactory, ConnectionFactory>();
            unityContainer.RegisterType<IUnitOfWork, UnitOfWork>();
            unityContainer.RegisterType<IMemberService, MemberService>();
            unityContainer.RegisterType<IBlogService, BlogService>();

            //// Instance a Table class object through Unity
            _memberService = unityContainer.Resolve<MemberService>();
            LoadSettings();
        }

        private static void LoadSettings()
        {
            XsrfKey = ConfigurationManager.AppSettings["XSRFKEY"];            
            Int32.TryParse(ConfigurationManager.AppSettings["club_id"], out Club_Id);
            Club_Admin_Email = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["admin_email"]) ? "ecom-log@tpfvietnam.vn" : ConfigurationManager.AppSettings["admin_email"];
            Club_Email = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["club_email"]) ? "ecom-log@tpfvietnam.vn" : ConfigurationManager.AppSettings["club_email"];
            Api_Domain = String.IsNullOrWhiteSpace(ConfigurationManager.AppSettings["api_domain"]) ? "http://jadechung-pc.vn.tpf" : ConfigurationManager.AppSettings["api_domain"];
            isMaintenance = !String.IsNullOrEmpty(ConfigurationManager.AppSettings["ismaintenance"]) && ConfigurationManager.AppSettings["ismaintenance"].ToString().ToLower() == "true" ? true : false;
            isDevelopment = !String.IsNullOrEmpty(ConfigurationManager.AppSettings["isdevelopment"]) && ConfigurationManager.AppSettings["isdevelopment"].ToString().ToLower() == "true" ? true : false;
            connectionString = String.IsNullOrEmpty(ConfigurationManager.ConnectionStrings["APIAppCon"].ConnectionString) ? "" : ConfigurationManager.ConnectionStrings["APIAppCon"].ConnectionString;
            MaxMember = 12;
            try
            {
                ClubViewModel club = _memberService.GetClub(Club_Id);
                if (club != null)
                {
                    Club_Name = club.Name;
                    Club_Domain = !isDevelopment ? "" : "http://localhost:3000";
                    LogoHeaderEmail = "mail-header-logo.png";
                    PublicKey = club.PublicKey;

                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}