﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EcommerceAPI.Helpers;

namespace EcommerceAPI.Controllers
{
    using DataAccess;
    using DataAccess.Constants;
    using DataAccess.Entities;
    using DataAccess.Services;
    using DataAccess.Utilities;
    using DataAccess.ViewModel;
    using EcommerceAPI.Models;
    using EcommerceAPI.Resources;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.Owin;
    using System.Threading.Tasks;
    using System.Web.Http.Description;

    /// <summary>
    /// To manage Members, 
    /// Get Special Requirements by Club
    /// Seating Preference by Club
    /// </summary>
    [Authorize]
    [RoutePrefix("api/Member")]
    public class MemberController : BaseApiController
    {
        //IMemberService _memberService;
        //private ApplicationUserManager _userManager;
        #region constructor MemberController
        public MemberController() : base()
        {

        }

        public MemberController(IMemberService memberService) : base()
        {
            this._memberService = memberService;
        }
        #endregion

        /// <summary>
        /// Get Seating Preference of your club from current the member manager
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetSeatingPreference")]
        [ResponseType(typeof(List<SeatingViewModel>))]
        public ActionResultHelper GetSeatingPreference()
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.MSG_SEATING_PREFERENCE_GET_UNSUCCESSFULLY;
            try
            {
                var user = UserManager.FindById(long.Parse(User.Identity.GetUserId()));
                List<SeatingViewModel> result = _memberService.GetSeatingPreference(user.ClubID);
                if (result != null && result.Count > 0)
                {
                    actionStatus.ActionResult = result;
                    actionStatus.Message = APIResource.MSG_SEATING_PREFERENCE_GET_SUCCESSFULLY;
                    actionStatus.ActionStatus = ResultSubmit.Success;
                }
                else
                {
                    actionStatus.ActionResult = null;
                    actionStatus.ActionStatus = ResultSubmit.Failed;
                }

                return actionStatus;
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex);
                EmailUtility.SendErrorEmail("SeatingPreference at MemberController", emailContent);
                actionStatus.ActionStatus = ResultSubmit.Failed;
                actionStatus.ErrorStrings.Add(emailContent);
                return actionStatus;
            }
        }

        /// <summary>
        /// Get Special Requirement of your club from current the member manager
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetSpecialRequirement")]
        [ResponseType(typeof(List<SpecialRequirementViewModel>))]
        public ActionResultHelper GetSpecialRequirement()
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.MSG_SPECIAL_REQUIREMENT_GET_UNSUCCESSFULLY;
            try
            {
                var user = UserManager.FindById(long.Parse(User.Identity.GetUserId()));
                List<SpecialRequirementViewModel> result = _memberService.GetSpecialRequirement(user.ClubID);
                if (result != null && result.Count > 0)
                {
                    actionStatus.ActionResult = result;
                    actionStatus.Message = APIResource.MSG_SPECIAL_REQUIREMENT_GET_SUCCESSFULLY;
                    actionStatus.ActionStatus = ResultSubmit.Success;
                }
                else
                {
                    actionStatus.ActionResult = null;
                    actionStatus.ActionStatus = ResultSubmit.Failed;
                }
                return actionStatus;
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex);
                EmailUtility.SendErrorEmail("GetSpecialRequirement at MemberController", emailContent);
                actionStatus.ActionStatus = ResultSubmit.Failed;
                actionStatus.ErrorStrings.Add(emailContent);
                return actionStatus;
            }
        }

        // Get api/Member/GetMemberInGroup
        /// <summary>
        /// Get Members In Group of the manager
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetMemberInGroup")]
        [ResponseType(typeof(List<MemberManagerViewModel>))]
        public async Task<IHttpActionResult> GetMemberInGroup()
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Account_Group_Member_In_Group_Not_Exist;
            long managerId = 0;
            try
            {
                managerId = long.Parse(User.Identity.GetUserId());
                var result = await _memberService.GetMemberInGroupOfManagerAsync(managerId, _clubID);
                if (result != null && result.Count() > 0)
                {
                    actionStatus.ActionResult = result;
                    actionStatus.Message = APIResource.Account_Get_Member_Successfully;
                    actionStatus.ActionStatus = ResultSubmit.Success;
                }
                else
                {
                    actionStatus.ActionResult = null;
                }
                return Ok(actionStatus);
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex, managerId);
                EmailUtility.SendErrorEmail("GetMemberInGroup at MemberController", emailContent);
                actionStatus.ErrorStrings.Add(emailContent);
                return Ok(actionStatus);
            }
        }
        /// <summary>
        /// Get Club info detail by ClubId
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>

        [AllowAnonymous]
        [HttpGet]
        [Route("GetClubInfo")]
        [ResponseType(typeof(ClubDetailInfoViewModel))]
        public ActionResultHelper GetClubInfo(int clubId = 0)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Club_ClubNotFound;
            try
            {
                if (clubId <= 0)
                {
                    return actionStatus;
                }
                ClubDetailInfoViewModel result = _memberService.GetClubDetailInfo(clubId);
                if (result != null && result.ID > 0)
                {
                    actionStatus.ActionResult = result;
                    actionStatus.Message = APIResource.Club_Club_Has_Loaded_Successfully;
                    actionStatus.ActionStatus = ResultSubmit.Success;
                }
                else
                {
                    actionStatus.ActionResult = null;
                }
                return actionStatus;
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex);
                EmailUtility.SendErrorEmail("GetClubInfo at MemberController", emailContent);
                actionStatus.ErrorStrings.Add(emailContent);
                return actionStatus;
            }
        }
        // GET api/Member/CheckMemberInGroup
        /// <summary>
        /// To Check member in group first when add to Group
        /// </summary>
        /// <param name="memberNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("CheckMemberInGroup")]
        [ResponseType(typeof(MemberManagerViewModel))]
        public async Task<IHttpActionResult> CheckMemberInGroup(string memberNumber)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Account_Group_Member_InValid;
            try
            {
                if (String.IsNullOrEmpty(memberNumber))
                {
                    actionStatus.ErrorStrings.Add(APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                    return Ok(actionStatus);
                }
                memberNumber = memberNumber.Trim();
                var user = await UserManager.FindByNameAsync(memberNumber);
                //get member in group

                int memberPriority = 0;
                int memberSeatingId = 0;

                if (user != null && user.Id > 0)
                {
                    var memberInGroup = _memberService.GetMemberInGroupByMemberNumber(memberNumber, _clubID);

                    if (memberInGroup == null)
                    {
                        actionStatus.Message = APIResource.Account_Group_Member_Valid;
                        actionStatus.ActionStatus = ResultSubmit.Success;

                        var managerId = long.Parse(User.Identity.GetUserId());
                        var result = await _memberService.GetMemberInGroupOfManagerAsync(managerId, _clubID);

                        if (result != null && result.Count()>0)
                        {
                            memberPriority = result.Count();
                            memberSeatingId = result.First().SeatingID;
                        }

                        var memberGroup = new MemberGroupViewModel();
                        memberGroup.ClubID = user.ClubID;
                        memberGroup.UserID = user.Id;
                        memberGroup.MemberID = user.UserName;
                        memberGroup.FirstName = user.FirstName;
                        memberGroup.LastName = user.LastName;
                        memberGroup.Priority = memberPriority;
                        memberGroup.SeatingID = memberSeatingId;
                        memberGroup.SpecialRequirementID = 0;
                        memberGroup.Email = user.Email;
                        actionStatus.ActionResult = memberGroup;
                        return Ok(actionStatus);
                    }

                    actionStatus.Message = APIResource.Account_Group_Member_Has_Registered_To_Add_Group;
                }
                else
                {
                    actionStatus.ActionResult = null;
                    actionStatus.Message = APIResource.Account_Group_Member_In_Group_Not_Exist;
                }
                return Ok(actionStatus);
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex);
                EmailUtility.SendErrorEmail("CheckMemberInGroup at MemberController", emailContent);
                actionStatus.Message = emailContent;
                return Ok(actionStatus);
            }
        }

        // POST api/Member/SaveGroup
        /// <summary>
        /// Update info for members in group
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SaveGroup")]
        [ResponseType(typeof(List<MemberGroupViewModel>))]
        public async Task<IHttpActionResult> SaveGroup(MemberGroupBindingModel model)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Account_Group_Member_InValid;
            bool IsValid = false;
            string message = string.Empty;
            try
            {
                //check group is exist
                var managerId = long.Parse(User.Identity.GetUserId());
                var user = UserManager.FindByIdAsync(managerId);
                var memberInGroup = await _memberService.GetMemberInGroupOfManagerAsync(managerId, _clubID);

                #region Model Validation
                if (!ModelState.IsValid || model == null)
                {
                    if (model != null)
                    {
                        actionStatus.ErrorModel = GetDetailErrorInModelState(ModelState);
                    }
                    else
                    {
                        actionStatus.ErrorStrings.Add(APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                    }
                    return Ok(actionStatus);
                }

                //check seating 
                if (model.GroupDetail.SeatingID <= 0 && model.GroupDetail.GroupStatus.ToLower() != nameof(GroupStatus.Step1).ToLower())                
                    actionStatus.ErrorStrings.Add(APIResource.Account_Group_Member_Check_Seating_Preference);
                
                if (model.MemberInGroup.Count <= 0 || model.MemberInGroup.Count > ClubConfiguration.MaxMember)                
                    actionStatus.ErrorStrings.Add(APIResource.Account_Group_Member_Check_Member_Total_In_Group);
                
                if (actionStatus.ErrorStrings.Count > 0)
                {
                    return Ok(actionStatus);
                }
                else
                {
                    IsValid = true;
                }
                //check the group be submited
                if (memberInGroup !=null && memberInGroup.Count() > 0 && memberInGroup.FirstOrDefault().GroupStatus == nameof(GroupStatus.Submited))
                {
                    IsValid = false;
                    actionStatus.ErrorStrings.Add(APIResource.Account_Group_Member_Have_Been_Submited);
                }
                #endregion
                
                if (IsValid)
                {                    
                    var membersToSave = new List<MemberGroupDetailBindingModel>();
                    model.GroupDetail.ClubID = user.Result.ClubID;

                    if (memberInGroup != null && memberInGroup.Count() > 0)
                    {
                        model.GroupDetail.GroupID = memberInGroup.First().GroupID;
                    }
                    
                    if (model.GroupDetail.GroupType == nameof(GroupType.Group))
                    {
                        foreach (var item in model.MemberInGroup)
                        {
                            var memberToUpdate = memberInGroup.FirstOrDefault(w => w.UserID == item.UserID);                            
                            if (item.UserID == managerId)
                            {
                                item.IsGroupManager = true;                                
                            }

                            if (memberToUpdate != null)
                            {
                                if (memberToUpdate.MemberGroupID>0)
                                {
                                    item.MemberGroupID = memberToUpdate.MemberGroupID;
                                }                                

                                switch (model.GroupDetail.GroupStatus)
                                {
                                    case nameof(GroupStatus.Step1):
                                        if (memberInGroup != null)
                                        {
                                            //group id type and who is manager

                                            //group id type single => check manager by your seft

                                            //else error display
                                        }
                                        else
                                        {
                                            //create group, add member to the group
                                        }
                                        break;
                                    case nameof(GroupStatus.Step2):

                                        item.MemberGroupID = memberToUpdate.MemberGroupID;

                                        break;
                                    case nameof(GroupStatus.Step3):

                                        break;
                                    case nameof(GroupStatus.Submited):

                                        break;
                                    default:
                                        break;
                                }
                            }
                            else //new member 
                            {
                                //check member in member account
                                var memberInAccount = UserManager.FindByIdAsync(item.UserID);
                                var memberOfGroup = await _memberService.GetMemberInGroupByMemberIdAsync(item.UserID, _clubID);
                                if (memberInAccount.Result == null)
                                {
                                    IsValid = false;
                                    actionStatus.ErrorStrings.Add(String.Format(" Account Member #{0} has not existed in system", item.MemberNumber));
                                }
                                //check member in other group
                                
                                if (memberOfGroup != null && memberOfGroup.GroupID != model.GroupDetail.GroupID)
                                {
                                    IsValid = false;
                                    actionStatus.ErrorStrings.Add(String.Format("Member #{0} has existed in group other", item.MemberNumber));
                                }
                            }

                            membersToSave.Add(item);
                        }
                    }
                    else if (model.GroupDetail.GroupType == nameof(GroupType.Single))
                    {
                        var memberSingleToSave = model.MemberInGroup.FirstOrDefault();  
                        memberSingleToSave.UserID = managerId;
                        memberSingleToSave.Priority = 1;
                        memberSingleToSave.IsGroupManager = true;
                        if(model.GroupDetail.GroupID > 0)
                        {
                            memberSingleToSave.MemberGroupID = model.GroupDetail.GroupID;
                        } 
                        membersToSave.Add(memberSingleToSave);
                    }

                    //save
                    if (membersToSave.Count > 0 && IsValid)
                    {
                        var result = _memberService.SaveMemberGroup(membersToSave, model.GroupDetail, out message);
                        if (result !=null && result.Count() > 0 && string.IsNullOrEmpty(message))
                        {
                            actionStatus.ActionResult = result;
                            actionStatus.Message = APIResource.Account_Group_Member_Have_Been_Saved;
                        }
                        else
                        {
                            actionStatus.Message = message;
                        }
                    }
                    else
                    {
                        return Ok(actionStatus);
                    }
                }

                #region handle error
                ErrorMemberLimit:
                if (!IsValid)
                {
                    actionStatus.ErrorStrings.Add(APIResource.Account_Group_Member_Check_Member_Total_In_Group);
                }
                #endregion

                return Ok(actionStatus);
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex);
                EmailUtility.SendErrorEmail("SaveGroup at MemberController", emailContent);
                actionStatus.Message = emailContent;
            }
            return Ok(actionStatus);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("StoreGroup")]
        public async Task<IHttpActionResult> StoreGroup(List<MemberGroupDetailBindingModel> model)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Account_Group_Member_InValid;

            return Ok(actionStatus);
        }

        [HttpPost]
        [Route("TestGroup")]
        public async Task<IHttpActionResult> TestGroup(GroupBindingModel group)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            actionStatus.Message = APIResource.Account_Group_Member_InValid;

            return Ok(actionStatus);
        }

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing && _userManager != null)
        //    {
        //        _userManager.Dispose();
        //        _userManager = null;
        //    }
        //    base.Dispose(disposing);
        //}
    }
}
