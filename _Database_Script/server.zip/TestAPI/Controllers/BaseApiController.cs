﻿using DataAccess.Services;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;

namespace EcommerceAPI.Controllers
{
    [Authorize]
    //[ApiExplorerSettings(IgnoreApi = true)]
    public class BaseApiController : ApiController
    {
        #region constructor
        public IMemberService _memberService;
        public ApplicationUserManager _userManager;
        public int _clubID;
        public BaseApiController()
        {
            _clubID = 1;
        }

        public BaseApiController(IMemberService memberService)
        {
            _memberService = memberService;
            _clubID = 1;
        }
        /// <summary>
        /// Current User info
        /// </summary>
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? Request.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }
        #endregion

        protected override void Dispose(bool disposing)
        {
            if (disposing && _userManager != null)
            {
                _userManager.Dispose();
                _userManager = null;
            }

            base.Dispose(disposing);
        }
        
        public static Dictionary<string, string> GetDetailErrorInModelState(ModelStateDictionary modelState)
        {
            var result = new Dictionary<string, string>();
            if (modelState != null)
            {
                foreach (var item in modelState)
                {
                    if (item.Value.Errors.Count > 0)
                    {
                        foreach (var erroritem in item.Value.Errors)
                        {
                            result.Add(item.Key, erroritem.ErrorMessage);
                        }
                    }
                }
            }
            return result;
        }

        public static List<string> GetErrorInModelState(ModelStateDictionary modelState)
        {
            var result = new List<string>();
            if (modelState != null)
            {
                foreach (var item in modelState)
                {
                    if (item.Value.Errors.Count > 0)
                    {
                        foreach (var erroritem in item.Value.Errors)
                        {
                            result.Add(erroritem.ErrorMessage);
                        }
                    }
                }
            }
            return result;
        }
    }
}
