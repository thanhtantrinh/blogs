﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using EcommerceAPI.Models;
using EcommerceAPI.Providers;
using EcommerceAPI.Results;
using System.IO;
using System.Net;
using DataAccess.ViewModel;
using RazorEngine;
using RazorEngine.Templating;
using EcommerceAPI.Helpers;
using EcommerceAPI.Resources;
using DataAccess.Constants;
using DataAccess.Utilities;
using System.Web.Http.Description;

namespace EcommerceAPI.Controllers
{
    /// <summary>
    /// To manager account
    /// </summary>    
    [Authorize]
    [RoutePrefix("api/Account")]    
    public class AccountController : ApiController
    {
        private const string LocalLoginProvider = "Local";
        private ApplicationUserManager _userManager;
        private const string XsrfKey = "XsrfId";

        public AccountController()
        {

        }

        public AccountController(ApplicationUserManager userManager,
            ISecureDataFormat<AuthenticationTicket> accessTokenFormat)
        {
            UserManager = userManager;
            AccessTokenFormat = accessTokenFormat;
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? Request.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        public ISecureDataFormat<AuthenticationTicket> AccessTokenFormat { get; private set; }

        #region enums

        public enum ManageMessageId
        {
            ChangePasswordSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
            Error
        }

        #endregion

        // GET api/Account/UserInfo
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        [HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        [Route("UserInfo")]
        public UserInfoViewModel GetUserInfo()
        {
            ExternalLoginData externalLogin = ExternalLoginData.FromIdentity(User.Identity as ClaimsIdentity);

            return new UserInfoViewModel
            {
                Email = User.Identity.GetUserName(),
                Username = User.Identity.GetUserName(),
                HasRegistered = externalLogin == null,
                LoginProvider = externalLogin != null ? externalLogin.LoginProvider : null
            };
        }

        // POST api/Account/Logout
        /// <summary>
        /// To Logout and clear token
        /// </summary>
        /// <returns></returns>
        [Route("Logout")]
        public IHttpActionResult Logout()
        {
            Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType);
            return Ok();
        }

        // GET api/Account/ManageInfo?returnUrl=%2F&generateState=true
        //[HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        [HttpGet]
        [ApiExplorerSettings(IgnoreApi = true)]
        [Route("ManageInfo")]
        public async Task<ManageInfoViewModel> GetManageInfo(string returnUrl, bool generateState = false)
        {
            var user = await UserManager.FindByIdAsync(long.Parse(User.Identity.GetUserId()));

            if (user == null)
            {
                return null;
            }

            List<UserLoginInfoViewModel> logins = new List<UserLoginInfoViewModel>();

            //foreach (IdentityUserLogin linkedAccount in user.Logins)
            //{
            //    logins.Add(new UserLoginInfoViewModel
            //    {
            //        LoginProvider = linkedAccount.LoginProvider,
            //        ProviderKey = linkedAccount.ProviderKey
            //    });
            //}

            if (user.PasswordHash != null)
            {
                logins.Add(new UserLoginInfoViewModel
                {
                    LoginProvider = LocalLoginProvider,
                    ProviderKey = user.UserName,
                });
            }

            return new ManageInfoViewModel
            {
                LocalLoginProvider = LocalLoginProvider,
                Username = user.UserName,
                Email = user.Email,
                Logins = logins,
                ExternalLoginProviders = GetExternalLogins(returnUrl, generateState)
            };
        }

        // POST api/Account/ChangePassword       
        /// <summary>
        /// Change password any user 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Route("ChangePassword")]
        //[ResponseType(typeof(ActionResultHelper))]
        public async Task<IHttpActionResult> ChangePassword(ChangePasswordBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            IdentityResult result = await UserManager.ChangePasswordAsync(long.Parse(User.Identity.GetUserId()), model.OldPassword, model.NewPassword);

            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }

            return Ok();
        }

        // POST api/Account/SetPassword
        /// <summary>
        /// Change password of current user
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [Route("SetPassword")]
        public async Task<IHttpActionResult> SetPassword(SetPasswordBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            IdentityResult result = await UserManager.AddPasswordAsync(long.Parse(User.Identity.GetUserId()), model.NewPassword);

            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }

            return Ok();
        }

        // POST api/Account/AddExternalLogin
        [ApiExplorerSettings(IgnoreApi = true)]
        [Route("AddExternalLogin")]
        public async Task<IHttpActionResult> AddExternalLogin(AddExternalLoginBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);

            AuthenticationTicket ticket = AccessTokenFormat.Unprotect(model.ExternalAccessToken);

            if (ticket == null || ticket.Identity == null || (ticket.Properties != null
                && ticket.Properties.ExpiresUtc.HasValue
                && ticket.Properties.ExpiresUtc.Value < DateTimeOffset.UtcNow))
            {
                return BadRequest("External login failure.");
            }

            ExternalLoginData externalData = ExternalLoginData.FromIdentity(ticket.Identity);

            if (externalData == null)
            {
                return BadRequest("The external login is already associated with an account.");
            }

            IdentityResult result = await UserManager.AddLoginAsync(long.Parse(User.Identity.GetUserId()),
                new UserLoginInfo(externalData.LoginProvider, externalData.ProviderKey));

            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }

            return Ok();
        }

        // POST api/Account/RemoveLogin
        [ApiExplorerSettings(IgnoreApi = true)]
        [Route("RemoveLogin")]
        public async Task<IHttpActionResult> RemoveLogin(RemoveLoginBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            IdentityResult result;

            if (model.LoginProvider == LocalLoginProvider)
            {
                result = await UserManager.RemovePasswordAsync(long.Parse(User.Identity.GetUserId()));
            }
            else
            {
                result = await UserManager.RemoveLoginAsync(long.Parse(User.Identity.GetUserId()),
                    new UserLoginInfo(model.LoginProvider, model.ProviderKey));
            }

            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }

            return Ok();
        }

        // GET api/Account/ExternalLogin
        [ApiExplorerSettings(IgnoreApi = true)]
        [OverrideAuthentication]
        [HostAuthentication(DefaultAuthenticationTypes.ExternalCookie)]
        [AllowAnonymous]
        [Route("ExternalLogin", Name = "ExternalLogin")]
        public async Task<IHttpActionResult> GetExternalLogin(string provider, string error = null)
        {
            if (error != null)
            {
                return Redirect(Url.Content("~/") + "#error=" + Uri.EscapeDataString(error));
            }

            if (!User.Identity.IsAuthenticated)
            {
                return new ChallengeResult(provider, this);
            }

            ExternalLoginData externalLogin = ExternalLoginData.FromIdentity(User.Identity as ClaimsIdentity);

            if (externalLogin == null)
            {
                return InternalServerError();
            }

            if (externalLogin.LoginProvider != provider)
            {
                Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                return new ChallengeResult(provider, this);
            }

            ApplicationUser user = await UserManager.FindAsync(new UserLoginInfo(externalLogin.LoginProvider,
                externalLogin.ProviderKey));

            bool hasRegistered = user != null;

            if (hasRegistered)
            {
                Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);

                ClaimsIdentity oAuthIdentity = await user.GenerateUserIdentityAsync(UserManager, OAuthDefaults.AuthenticationType);
                ClaimsIdentity cookieIdentity = await user.GenerateUserIdentityAsync(UserManager, CookieAuthenticationDefaults.AuthenticationType);

                AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user);
                Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
            }
            else
            {
                IEnumerable<Claim> claims = externalLogin.GetClaims();
                ClaimsIdentity identity = new ClaimsIdentity(claims, OAuthDefaults.AuthenticationType);
                Authentication.SignIn(identity);
            }

            return Ok();
        }

        // GET api/Account/ExternalLogins?returnUrl=%2F&generateState=true
        [ApiExplorerSettings(IgnoreApi = true)]
        [AllowAnonymous]
        [Route("ExternalLogins")]
        public IEnumerable<ExternalLoginViewModel> GetExternalLogins(string returnUrl, bool generateState = false)
        {
            IEnumerable<AuthenticationDescription> descriptions = Authentication.GetExternalAuthenticationTypes();
            List<ExternalLoginViewModel> logins = new List<ExternalLoginViewModel>();

            string state;

            if (generateState)
            {
                const int strengthInBits = 256;
                state = RandomOAuthStateGenerator.Generate(strengthInBits);
            }
            else
            {
                state = null;
            }

            foreach (AuthenticationDescription description in descriptions)
            {
                ExternalLoginViewModel login = new ExternalLoginViewModel
                {
                    Name = description.Caption,
                    Url = Url.Route("ExternalLogin", new
                    {
                        provider = description.AuthenticationType,
                        response_type = "token",
                        client_id = Startup.PublicClientId,
                        redirect_uri = new Uri(Request.RequestUri, returnUrl).AbsoluteUri,
                        state = state
                    }),
                    State = state
                };
                logins.Add(login);
            }

            return logins;
        }

        // POST api/Account/Register
        /// <summary>
        /// To create member
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost]
        [Route("Register")]
        public async Task<IHttpActionResult> Register(RegisterBindingModel model)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            if (!ModelState.IsValid || model == null)
            {
                if (model != null)
                {
                    actionStatus.ErrorModel = GetDetailErrorInModelState(ModelState);
                }
                else
                {
                    actionStatus.ErrorStrings.Add(APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                }
                return BadRequest(ModelState);

            }
            var user = new ApplicationUser()
            {
                UserName = model.MemberId,
                Email = model.Email,
                FirstName = "Trung",
                LastName = "Nguyen",
                CreatedDate = DateTime.Now,
                UpdatedDate = DateTime.Now,
                ClubID = 1
            };
            try
            {
                IdentityResult result = await UserManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    AddErrors(result);
                    foreach (string error in result.Errors)
                    {
                        ModelState.AddModelError("", error);
                    }
                    return BadRequest(ModelState);
                }
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex, model);
                EmailUtility.SendErrorEmail("Register", emailContent);
                ModelState.AddModelError("ErrorSystem", emailContent);
                return BadRequest(ModelState);
            }
            actionStatus.ActionStatus = ResultSubmit.Success;
            actionStatus.Message = String.Format(APIResource.MSG_THE_ACCOUNT_HAS_BEEN_CREATED, user.UserName);
            return Ok(actionStatus);
        }

        // POST api/Account/RegisterExternal
        [ApiExplorerSettings(IgnoreApi = true)]
        [OverrideAuthentication]
        [HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        [Route("RegisterExternal")]
        public async Task<IHttpActionResult> RegisterExternal(RegisterExternalBindingModel model)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var info = await Authentication.GetExternalLoginInfoAsync();
            if (info == null)
            {
                return InternalServerError();
            }

            var user = new ApplicationUser() { UserName = model.Email, Email = model.Email };

            IdentityResult result = await UserManager.CreateAsync(user);
            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }

            result = await UserManager.AddLoginAsync(user.Id, info.Login);
            if (!result.Succeeded)
            {
                return GetErrorResult(result);
            }
            return Ok();
        }
        /// <summary>
        /// Enter your email of member to see token and reset password
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        // POST: api/Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [Route("ForgotPassword")]
        //[HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        public async Task<IHttpActionResult> ForgotPassword(ForgotPasswordBindingModel model)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            try
            {
                if (!ModelState.IsValid || model == null)
                {
                    if (model != null)
                    {
                        actionStatus.ErrorModel = GetDetailErrorInModelState(ModelState);
                    }
                    else
                    {
                        actionStatus.ErrorStrings.Add(APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                    }
                    return BadRequest(ModelState);
                }

                var user = await UserManager.FindByEmailAsync(model.Email);
                if (user == null || !(await UserManager.IsEmailConfirmedAsync(user.Id)))
                {
                    //ModelState.AddModelError("", "The user either does not exist or is not confirmed.");
                    //return BadRequest(ModelState);
                    actionStatus.ErrorStrings.Add(APIResource.MSG_FORGOT_PASSWORD_WARNING_USER_INVALID);
                    return Ok(actionStatus);
                }

                #region block Send Mail 
                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                // Send an email with this link
                string code = await UserManager.GeneratePasswordResetTokenAsync(user.Id);
                code = HttpUtility.UrlEncode(code);
                //var callbackUrl = this.Url.Link("DefaultApi", new { Controller = "Account", Action = "ResetPassword", userId = user.Id, code = code });
                //var callbackUrl = this.Url.Link("Default", new { Controller = "Account", Action = "ResetPassword", userId = user.Id, code = code });
                var callbackUrl = String.Format("{0}/new-password/{1}/{2}", ClubConfiguration.Club_Domain, user.Id, code);

                //var response = new HttpRequestMessage(HttpStatusCode.OK);
                string viewPath = HttpContext.Current.Server.MapPath(@"~/Views/Shared/_EmailResetPassword.cshtml");
                var template = File.ReadAllText(viewPath);

                string urlEmailHederImageLogo = "";
                string UrlBaseClub = ClubConfiguration.Club_Domain;
                if (ClubConfiguration.isDevelopment)
                {
                    //urlEmailHederImageLogo = String.Format("{0}{1}", HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority), APIResource.Dir_Images);
                    //UrlBaseClub = HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority);
                    urlEmailHederImageLogo = String.Format("{0}{1}", ClubConfiguration.Api_Domain, APIResource.Dir_Images);
                    UrlBaseClub = ClubConfiguration.Club_Domain;
                }
                else
                {
                    urlEmailHederImageLogo = String.Format("{0}{1}", ClubConfiguration.Club_Domain, APIResource.Dir_Images);
                    UrlBaseClub = ClubConfiguration.Club_Domain;
                }
                string emailContent = Engine.Razor.RunCompile(template, "templateKey", typeof(EmailResetPasswordViewModel), new EmailResetPasswordViewModel
                {
                    TokenLink = callbackUrl,
                    UserName = user.UserName,
                    Club_Name = ClubConfiguration.Club_Name,
                    UrlHeaderLogo = String.Format(urlEmailHederImageLogo, ClubConfiguration.LogoHeaderEmail),
                    YearNow = DateTime.Now.Year.ToString(),
                    Club_Email = ClubConfiguration.Club_Email,
                    Club_Domain = UrlBaseClub,
                });

                await UserManager.SendEmailAsync(user.Id, APIResource.LABEL_RESET_PASSWORD, emailContent);

                #endregion

                actionStatus.ErrorStrings.Add(APIResource.MSG_FORGOT_PASSWORD_CONTENT_SEND_MAIL);
                actionStatus.ActionStatus = ResultSubmit.Success;

                //task.Wait();

                return Ok(actionStatus);
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex, model);
                EmailUtility.SendErrorEmail("ResetPassword", emailContent);
                ModelState.AddModelError("ErrorSystem", emailContent);
                return BadRequest(ModelState);
            }
        }
        // Get api/Account/ResetPassword
        /// <summary>
        /// To check availability token of Member
        /// </summary>
        /// <param name="code">Token</param>
        /// <param name="userId">Id or UserId of Member</param>
        /// <returns></returns>
        [HttpGet]
        [AllowAnonymous]
        [Route("ResetPassword")]
        [ResponseType(typeof(ActionResultHelper))]
        public IHttpActionResult ResetPassword(string code, long userId)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            try
            {
                if (String.IsNullOrEmpty(code) || userId <= 0)
                {
                    //actionStatus.ErrorStrings.Add(APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                    ModelState.AddModelError("", APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                    return BadRequest(ModelState);
                }

                code = WebUtility.UrlDecode(code);
                code = code.Replace(' ', '+');

                if (!UserManager.VerifyUserToken(userId, "ResetPassword", code))
                {
                    ModelState.AddModelError("", APIResource.MSG_RESET_PASSWORD_TOKEN_INVALID);
                    return BadRequest(ModelState);
                }
            }
            catch (Exception ex)
            {
                string emailContent = CommonUtilities.Parameters2ErrorString(ex, code, userId);
                EmailUtility.SendErrorEmail("ResetPassword", emailContent);

                //ModelState.AddModelError("", emailContent);
                ModelState.AddModelError("ErrorSystem", APIResource.Admin_System_StopOnError);
                return BadRequest(ModelState);
            }

            actionStatus.ErrorStrings.Add(APIResource.MSG_RESET_PASSWORD_TOKEN_VALID);
            actionStatus.ActionStatus = ResultSubmit.Success;
            actionStatus.ActionResult = code;
            return Ok(actionStatus);
        }

        // Put api/Account/ResetPassword
        /// <summary>
        /// Enter info to reset pasword
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPut]
        [AllowAnonymous]
        [Route("ResetPassword")]
        [ResponseType(typeof(ActionResultHelper))]
        public async Task<IHttpActionResult> ResetPassword(ResetPasswordBindingModel model)
        {
            var actionStatus = new ActionResultHelper();
            actionStatus.ActionStatus = ResultSubmit.Failed;
            if (!ModelState.IsValid || model == null)
            {
                if (model == null)
                {
                    ModelState.AddModelError("", APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                }
                return BadRequest(ModelState);
            }

            var user = UserManager.FindById(model.UserId);
            if (user == null)
            {
                //ModelState.AddModelError("", "No user found.");
                //return BadRequest(ModelState);
                //actionStatus.ErrorStrings.Add(APIResource.MSG_MEMBER_HAS_NOT_FOUND);
                ModelState.AddModelError("", APIResource.MSG_WARNING_PARAMETER_IS_NULL);
                return BadRequest(ModelState);
            }
            var code = WebUtility.UrlDecode(model.Code);
            code = code.Replace(' ', '+');
            var result = await UserManager.ResetPasswordAsync(user.Id, code, model.Password);
            if (!result.Succeeded)
            {
                // If we got this far, something failed, redisplay form
                AddErrors(result);
                return BadRequest(ModelState);
            }

            actionStatus.ActionStatus = ResultSubmit.Success;
            actionStatus.Message = APIResource.MSG_YOUR_PASSWORD_HAS_BEEN_CHANGED;
            return Ok(actionStatus);
        }
        
        #region Helpers

        protected override void Dispose(bool disposing)
        {
            if (disposing && _userManager != null)
            {
                _userManager.Dispose();
                _userManager = null;
            }

            base.Dispose(disposing);
        }

        private IAuthenticationManager Authentication
        {
            get { return Request.GetOwinContext().Authentication; }
        }

        private IHttpActionResult GetErrorResult(IdentityResult result)
        {
            if (result == null)
            {
                return InternalServerError();
            }

            if (!result.Succeeded)
            {
                if (result.Errors != null)
                {
                    foreach (string error in result.Errors)
                    {
                        ModelState.AddModelError("", error);
                    }
                }

                if (ModelState.IsValid)
                {
                    // No ModelState errors are available to send, so just return an empty BadRequest.
                    return BadRequest();
                }

                return BadRequest(ModelState);
            }

            return null;
        }

        private class ExternalLoginData
        {
            public string LoginProvider { get; set; }
            public string ProviderKey { get; set; }
            public string UserName { get; set; }

            public IList<Claim> GetClaims()
            {
                IList<Claim> claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.NameIdentifier, ProviderKey, null, LoginProvider));

                if (UserName != null)
                {
                    claims.Add(new Claim(ClaimTypes.Name, UserName, null, LoginProvider));
                }

                return claims;
            }

            public static ExternalLoginData FromIdentity(ClaimsIdentity identity)
            {
                if (identity == null)
                {
                    return null;
                }

                Claim providerKeyClaim = identity.FindFirst(ClaimTypes.NameIdentifier);

                if (providerKeyClaim == null || String.IsNullOrEmpty(providerKeyClaim.Issuer)
                    || String.IsNullOrEmpty(providerKeyClaim.Value))
                {
                    return null;
                }

                if (providerKeyClaim.Issuer == ClaimsIdentity.DefaultIssuer)
                {
                    return null;
                }

                return new ExternalLoginData
                {
                    LoginProvider = providerKeyClaim.Issuer,
                    ProviderKey = providerKeyClaim.Value,
                    UserName = identity.FindFirstValue(ClaimTypes.Name)
                };
            }
        }

        private static class RandomOAuthStateGenerator
        {
            private static RandomNumberGenerator _random = new RNGCryptoServiceProvider();

            public static string Generate(int strengthInBits)
            {
                const int bitsPerByte = 8;

                if (strengthInBits % bitsPerByte != 0)
                {
                    throw new ArgumentException("strengthInBits must be evenly divisible by 8.", "strengthInBits");
                }

                int strengthInBytes = strengthInBits / bitsPerByte;

                byte[] data = new byte[strengthInBytes];
                _random.GetBytes(data);
                return HttpServerUtility.UrlTokenEncode(data);
            }
        }
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        public static Dictionary<string, string> GetDetailErrorInModelState(ModelStateDictionary modelState)
        {
            var result = new Dictionary<string, string>();
            if (modelState != null)
            {
                foreach (var item in modelState)
                {
                    if (item.Value.Errors.Count > 0)
                    {
                        foreach (var erroritem in item.Value.Errors)
                        {
                            result.Add(item.Key, erroritem.ErrorMessage);
                        }
                    }
                }
            }
            return result;
        }

        public static List<string> GetErrorInModelState(ModelStateDictionary modelState)
        {
            var result = new List<string>();
            if (modelState != null)
            {
                foreach (var item in modelState)
                {
                    if (item.Value.Errors.Count > 0)
                    {
                        foreach (var erroritem in item.Value.Errors)
                        {
                            result.Add(erroritem.ErrorMessage);
                        }
                    }
                }
            }
            return result;
        }
        #endregion
    }
}
