﻿using DataAccess.EntitiesDataBase;
using DataAccess.Services;
using DataAccess.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EcommerceAPI.Controllers
{
    public class HomeController : Controller
    {
        IMemberService _memberService;
        public HomeController()
        {

        }

        public HomeController(IMemberService memberService)
        {
            _memberService = memberService;
        }


        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            return View();
        }

        public ActionResult EmailResetPassword()
        {
            //Club result = _memberService.GetClub(1);
            var model = new ResetPasswordRequest();

            model.Username = "TanTrinh";
            model.TokenLink = "tadsfsdfs";
            return View(model);
        }
    }
}
