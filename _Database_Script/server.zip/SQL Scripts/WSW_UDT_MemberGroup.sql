-- ================================
-- Create User-defined Table Type
-- ================================
USE WSW;
GO

-- Create the data type
CREATE TYPE WSW_UDT_MemberOfGroup AS TABLE 
(
	MemberGroupID BIGINT,
	UserID BIGINT,
	MemberNumber NVARCHAR(50),
	SpecialRequirementID INT,
	IsGroupManager BIT,
	[Priority] INT,
	Attachment NVARCHAR(50),
	OtherRequirement NVARCHAR(500),
	GroupID INT
)
GO
