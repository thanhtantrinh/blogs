﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Utilities
{
    public static class CommonUtilities
    {
        public static string Parameters2ErrorString(Exception e, params object[] parameters)
        {
            var ps = "Error: " + e.Message + (parameters.Length > 0 ? ("<br>Parameters:" + String.Join(", ", parameters)) : "");
            return ps;
        }
    }
}
