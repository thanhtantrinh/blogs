﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace DataAccess.Utilities
{
    public static class EmailUtility 
    {
        /// <summary>
        /// Sever to send out
        /// </summary>
        private const string _mailServer    = "sendmail.tpf.com.au";
        /// <summary>
        /// Mail to notify error to manager
        /// </summary>
        private const string _mailAdmin     = "tantrinh@tpfvietnam.vn";
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="html"></param>
        public static void SendEmail(string to, string from, string subject, string body, bool html = true)
        {
            try
            {
                MailMessage message = new MailMessage(from, to, subject, body);
                message.IsBodyHtml = html;                
                SmtpClient client = new SmtpClient(_mailServer);
                client.Send(message);
            }
            catch (Exception ex)
            {
                //oh well, we're boned. give up.
                throw;                
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        public static void SendEmail(string to, string from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to, subject, body);
                message.IsBodyHtml = true;
                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }
                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                SmtpClient client = new SmtpClient(_mailServer);
                client.Send(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        /// <returns></returns>
        public static async Task SendEmailAsync(string to, string from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to, subject, body);
                message.IsBodyHtml = true;
                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }
                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                //SmtpClient client = new SmtpClient("mailserver");
                SmtpClient client = new SmtpClient(_mailServer);
                //client.SendAsync(message, null);
                await client.SendMailAsync(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="to"></param>
        /// <param name="from"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="cc"></param>
        /// <param name="bcc"></param>
        /// <returns></returns>
        public static async Task SendEmailAsync(MailAddress to, MailAddress from, string subject, string body, string[] cc = null, string[] bcc = null)
        {
            try
            {
                MailMessage message = new MailMessage(from, to);
                message.IsBodyHtml = true;
                message.From = from;
                message.Subject = subject;
                message.Body = body;

                if (bcc != null && bcc.Count() > 0)
                {
                    Array.ForEach(bcc, m => message.Bcc.Add(new MailAddress(m)));
                }

                if (cc != null && cc.Count() > 0)
                {
                    Array.ForEach(cc, m => message.CC.Add(new MailAddress(m)));
                }
                SmtpClient client = new SmtpClient(_mailServer);
                await client.SendMailAsync(message);
            }
            catch (Exception e)
            {
                //oh well, we're boned. give up.
                Console.Write(e.Message);
            }
        }

        /// <summary>
        /// Send Email Error for internal system
        /// </summary>
        /// <param name="subject">Subject Email</param>
        /// <param name="body">Content of Email</param>
        /// <param name="html"></param>
        public static void SendErrorEmail(string subject, string body, bool html = true)
        {            
            SendEmail(_mailAdmin, "errors@tpf.com.au", "EcommerceAPI:: " + subject, body, html);
        }

    }
}
