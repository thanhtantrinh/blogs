﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper.Contrib.Extensions;

namespace DataAccess.Entities
{
    [Table("WSW_Club")]
    public class ClubViewModel
    {
        [Key]
        //[ExplicitKey]
        public int ID { get; set; }
        public string PublicKey { get; set; }
        public string Name { get; set; }
        public string NickName { get; set; }
        public string Logo { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Style { get; set; }
    }

    [Table("WSW_SpecialRequirement")]
    public class SpecialRequirementViewModel
    {
        [Key]
        public int ID { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int ClubID { get; set; }
    }

    [Table("WSW_ClubInfo")]
    public class ClubInfoViewModel
    {
        [Key]
        public int ID { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public string Path { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int ClubID { get; set; }
    }
    /// <summary>
    /// Club Detail will be full information
    /// </summary>
    public class ClubDetailInfoViewModel
    {
        /// <summary>
        /// Club Id
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// Club Public Key
        /// </summary>
        public string PublicKey { get; set; }
        /// <summary>
        /// Club Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Nick Name or short name
        /// </summary>
        public string NickName { get; set; }
        /// <summary>
        /// path of club Logo
        /// </summary>
        public string Logo { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Style { get; set; }
        public List<SpecialRequirementViewModel> ListSpecialRequirement { get; set; }
        public List<SeatingViewModel> ListSeatingPreference  { get; set; }
        public List<ClubInfoViewModel> ListClubInfo { get; set; }
        public ClubDetailInfoViewModel()
        {
            ListSpecialRequirement = new List<SpecialRequirementViewModel>();
            ListSeatingPreference = new List<SeatingViewModel>();
            ListClubInfo = new List<ClubInfoViewModel>();
        }
    }

    /// <summary>
    /// Table of MemberGroup
    /// </summary>
    [Table("WSW_MemberGroup")]
    public class MemberGroup
    {
        public long ID { get; set; }
        public long MemberID { get; set; }        
        public int SpecialRequirementID { get; set; }
        public bool IsGroupManager { get; set; }
        public int Priority { get; set; }
        public string Attachment { get; set; }
        public string OtherRequirement { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
