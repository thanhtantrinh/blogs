﻿using System;
using Dapper.Contrib.Extensions;

namespace DataAccess.Entities
{

    [Table("WSW_SeatingPref")]
    public class SeatingViewModel
    {
        /// <summary>
        /// Seating Id
        /// </summary>
        [Key]        
        public int ID { get; set; }
        /// <summary>
        /// Seating Zone Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// Create Date
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Update Date
        /// </summary>
        public DateTime UpdatedDate { get; set; }
        /// <summary>
        /// Club Id
        /// </summary>
        public int ClubID { get; set; }
    }
}
