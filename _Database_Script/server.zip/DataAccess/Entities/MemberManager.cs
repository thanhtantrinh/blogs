﻿using System;
using System.Collections.Generic;

namespace DataAccess.Entities
{
    public class MemberManagerViewModel
    {
        /// <summary>
        /// ID of User or Member or Account Web
        /// </summary>
        public long ID { get; set; }
        /// <summary>
        /// ClubID of Current Member when logged
        /// </summary>
        public int ClubID { get; set; }
        /// <summary>
        /// MemberID is like the Username(Username's Member) of Current Member of Account Web
        /// </summary>
        public string MemberID { get; set; }
        /// <summary>
        /// FirstName of Member
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// LastName of Member
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// Email of Member
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// PhoneNumber of Member
        /// </summary>
        public string PhoneNumber { get; set; }
        /// <summary>
        /// The Members in group have been managed by this member
        /// </summary>
        public List<MemberGroupViewModel> MemberGroup { get; set; }
        
        /// <summary>
        /// Constructor
        /// </summary>
        public MemberManagerViewModel()
        {
            MemberGroup = new List<MemberGroupViewModel>();
        }
    }

    public class MemberGroupViewModel
    {
        /// <summary>
        /// ID is key in MemberGroup table
        /// </summary>
        public long MemberGroupID { get; set; }

        #region Info Member common in Group
        /// <summary>
        /// ClubID is key of Club table
        /// </summary>
        public int ClubID { get; set; }
        /// <summary>
        /// ID is key in Member table 
        /// </summary>
        public long UserID { get; set; }
        /// <summary>
        /// MemberID is like the Username(Username's Member) of Account Web
        /// </summary>
        public string MemberID { get; set; }
        /// <summary>
        /// FirstName of Member in Group
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// LastName of Member in Group
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// Email of Member in Group
        /// </summary>
        public string Email { get; set; }

        public string Status { get; set; }
        #endregion

        #region Info Member details in the group
        /// <summary>
        /// ID for Seating Preference
        /// </summary>
        public int SeatingID { get; set; }
        /// <summary>
        /// ID for Special Requirements
        /// </summary>
        public int SpecialRequirementID { get; set; }
        /// <summary>
        /// Do you have Group Manager
        /// </summary>
        public bool IsGroupManager { get; set; }
        /// <summary>
        /// Value for sort
        /// </summary>
        public int Priority { get; set; }
        /// <summary>
        /// path for the attachment file
        /// </summary>
        public string Attachment { get; set; }
        /// <summary>
        /// To store for the other requirement 
        /// </summary>
        public string OtherRequirement { get; set; }
        /// <summary>
        /// The times when member added to group
        /// </summary>
        public DateTime MemberGroupCreatedDate { get; set; }
        /// <summary>
        /// The times when modify member 
        /// </summary>
        public DateTime MemberGroupUpdatedDate { get; set; }
        #endregion

        #region Info Group Detail
        /// <summary>
        /// Group Id
        /// </summary>
        public int GroupID { get; set; }
        /// <summary>
        /// Group Name
        /// </summary>
        public string GroupName { get; set; }
        /// <summary>
        /// Group Type
        /// </summary>
        public string GroupNote { get; set; }
        /// <summary>
        /// Group Status Pending or Submited
        /// </summary>
        public string GroupStatus { get; set; }
        /// <summary>
        /// GroupType Single or Group
        /// </summary>
        public string GroupType { get; set; }
        #endregion

    }
    
}
