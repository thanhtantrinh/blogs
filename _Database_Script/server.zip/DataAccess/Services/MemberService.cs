﻿using DataAccess.Entities;
using DataAccess.EntitiesDataBase;
using DataAccess.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Utilities;
using System.Data;
using DataAccess.Constants;

namespace DataAccess.Services
{
    public class MemberService : IMemberService
    {
        IUnitOfWork _unitOfWork;
        public MemberService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Service to get Club
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public ClubViewModel GetClub(int clubId = 0)
        {
            var result = new ClubViewModel();
            try
            {
                result = _unitOfWork.ClubRepository.GetClub(clubId);
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetClub at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return result;
        }

        /// <summary>
        /// Get Special Requirement List by Club Id
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public List<SpecialRequirementViewModel> GetSpecialRequirement(int clubId = 0)
        {
            var result = new List<SpecialRequirementViewModel>();
            try
            {
                result = _unitOfWork.SpecialRequirementRepository.GetSpecialRequirement(clubId).ToList();
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSpecialRequirement at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return result;
        }

        /// <summary>
        /// Get Seating Preference
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public List<SeatingViewModel> GetSeatingPreference(int clubId = 0)
        {
            var result = new List<SeatingViewModel>();
            try
            {
                if (clubId > 0)
                {
                    result = _unitOfWork.SeatingRepository.GetSeatingPreference(clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSeatingPreference at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return result;
        }
        /// <summary>
        /// Get Club Detail Info
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public ClubDetailInfoViewModel GetClubDetailInfo(int clubId = 0)
        {
            var result = new ClubDetailInfoViewModel();
            try
            {
                if (clubId > 0)
                {
                    result = _unitOfWork.ClubRepository.GetClubDetailInfo(clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetClubDetailInfo at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return result;
        }
        /// <summary>
        /// Get Member In Group by ManagerId
        /// </summary>
        /// <param name="managerId"></param>
        /// <returns></returns>
        public IEnumerable<MemberGroupViewModel> GetMemberInGroupOfManager(long managerId = 0, int clubId=0)
        {
            try
            {
                if (managerId > 0)
                {
                    return _unitOfWork.MemberRepository.GetMemberInGroupOfManager(managerId, clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, managerId);
                string subjectMail = "At GetMemberInGroupOfManager at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return null;
        }
        /// <summary>
        /// Get Member In Group by ManagerId with Async
        /// </summary>
        /// <param name="managerId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<MemberGroupViewModel>> GetMemberInGroupOfManagerAsync(long managerId = 0, int clubId=0)
        {
            try
            {
                if (managerId > 0 && clubId>0)
                {
                    return await _unitOfWork.MemberRepository.GetMemberInGroupOfManagerAsync(managerId, clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, managerId);
                string subjectMail = "At GetMemberInGroupOfManagerAsync at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return null;
        }

        /// <summary>
        /// Count Member In Group by groupID with Async
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        public async Task<int> CountMemberInGroupAsync(int groupID = 0)
        {
            try
            {
                if (groupID > 0)
                {
                    return await _unitOfWork.MemberRepository.CountMemberOfGroupByGroupIdAsync(groupID);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, groupID);
                string subjectMail = "At CountMemberInGroupAsync at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return 0;
        }

        /// <summary>
        /// Get Member In Group by ManagerId or UserName
        /// </summary>
        /// <param name="managerId"></param>
        /// <returns></returns>
        public MemberGroupViewModel GetMemberInGroupByMemberNumber(string memberNumber, int clubId)
        {
            try
            {
                if (!String.IsNullOrEmpty(memberNumber) && clubId>0)
                {
                    return _unitOfWork.MemberRepository.GetMemberInGroupByMemberNumber(memberNumber, clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberNumber);
                string subjectMail = "At GetMemberInGroupByMemberNumber at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return null;
        }

        public async Task<MemberGroupViewModel> GetMemberInGroupByMemberIdAsync(long memberId, int clubId)
        {
            try
            {
                if (memberId >0 && clubId > 0)
                {
                    return await _unitOfWork.MemberRepository.GetMemberInGroupByMemberIdAsync(memberId, clubId);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberId, clubId);
                string subjectMail = "At GetMemberInGroupByMemberIdAsync at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            return null;
        }
        
        public IEnumerable<MemberGroupViewModel> SaveMemberGroup(List<MemberGroupDetailBindingModel> model, GroupBindingModel group, out string errorDisplay)
        {
            errorDisplay = String.Empty;
            try
            {                
                //check data
                var result = _unitOfWork.MemberRepository.SaveMemberGroup(model, group, out errorDisplay);
                if (result)
                {
                    var managerId = model.FirstOrDefault(f => f.IsGroupManager == true).UserID;
                    if (managerId > 0)
                    {
                        return _unitOfWork.MemberRepository.GetMemberInGroupOfManager(managerId, group.ClubID);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, model, group);
                string subjectMail = "At SaveMemberGroup at MemberService at DataAccess.Services";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
                errorDisplay = ex.Message;
            }
            return null;
        }



    }
}
