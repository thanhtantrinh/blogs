﻿using DataAccess.Entities;
using DataAccess.EntitiesDataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Services
{
    public interface IMemberService
    {
        /// <summary>
        /// Get Club Info by Id
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        ClubViewModel GetClub(int clubId);
        /// <summary>
        /// Get Special Requirement by ClubId
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        List<SpecialRequirementViewModel> GetSpecialRequirement(int clubId);
        /// <summary>
        /// Get Seating Preference by ClubId
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        List<SeatingViewModel> GetSeatingPreference(int clubId);
        /// <summary>
        /// Get Club Detail Full Info
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        ClubDetailInfoViewModel GetClubDetailInfo(int clubId);
        /// <summary>
        /// Get Members in Group by ManagerId
        /// </summary>
        /// <param name="managerId"></param>
        /// <returns></returns>
        IEnumerable<MemberGroupViewModel> GetMemberInGroupOfManager(long managerId, int clubId);
        /// <summary>
        /// Get Members in Group by ManagerId with Async
        /// </summary>
        /// <param name="managerId"></param>
        /// <returns></returns>
        Task<IEnumerable<MemberGroupViewModel>> GetMemberInGroupOfManagerAsync(long managerId, int clubId);
        /// <summary>
        /// Get Member has registered In Group by memberNumber
        /// </summary>
        /// <param name="memberNumber"></param>
        /// <returns></returns>
        MemberGroupViewModel GetMemberInGroupByMemberNumber(string memberNumber, int clubId);

        /// <summary>
        /// Get Member has registered In Group by memberId
        /// </summary>
        /// <param name="memberNumber"></param>
        /// <returns></returns>
        //Task<MemberGroupViewModel> GetMemberInGroupByMemberIdAsync(long memberId);
        Task<MemberGroupViewModel> GetMemberInGroupByMemberIdAsync(long memberId, int clubId);
        /// <summary>
        /// Count Member In Group by groupID
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        Task<int> CountMemberInGroupAsync(int groupID);
        //Task<int> GroupByIdAsync(int groupID);

        //bool CheckGroupExistOfManager(long managerId);
        //Task<bool> CheckGroupExistOfManagerAsync(long managerId);
        IEnumerable<MemberGroupViewModel> SaveMemberGroup(List<MemberGroupDetailBindingModel> model, GroupBindingModel group, out string errorDisplay);
    }
}
