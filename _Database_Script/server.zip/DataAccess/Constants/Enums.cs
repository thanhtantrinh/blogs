﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Constants
{
    /// <summary>
    /// Status Group
    /// </summary>
    public enum SpecialRequirementType
    {
        None,
        Attachment,
        Other
    }
    /// <summary>
    /// Status Group
    /// </summary>
    public enum GroupStatus
    {
        /// <summary>
        /// Pending is default
        /// </summary>
        Pending,
        /// <summary>
        /// view manage group
        /// </summary>
        Step1,
        /// <summary>
        /// view seating preference
        /// </summary>
        Step2,
        /// <summary>
        /// View special requirements
        /// </summary>
        Step3,
        /// <summary>
        /// Status finished
        /// </summary>
        Submited
    }
    /// <summary>
    /// Type Group
    /// </summary>
    public enum GroupType
    {
        Single,
        Group
    }
    public enum ResultSubmit
    {
        Failed = 0,
        Success = 1
    }

    public enum EntityStatus
    {
        Deleted = 0,
        Active = 1,
        Pending = 2,
    }
}
