﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Constants
{
    public class Constant
    {

    }
    public class ActionResultHelper
    {
        public ResultSubmit ActionStatus { get; set; }
        public string Message { get; set; }
        public List<string> ErrorStrings { get; set; }
        public Dictionary<string,string> ErrorModel { get; set; }
        public dynamic ActionResult { get; set; }
        public ActionResultHelper()
        {
            this.ActionStatus = ResultSubmit.Success;
            this.Message = String.Empty;
            this.ErrorStrings = new List<string>();
            this.ErrorModel = new Dictionary<string, string>();
            this.ActionResult = null;
        }
    }
}
