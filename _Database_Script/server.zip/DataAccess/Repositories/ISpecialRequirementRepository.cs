﻿using DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public interface ISpecialRequirementRepository : IGenericRepository<SpecialRequirementViewModel>
    {
        /// <summary>
        /// Get SpecialRequirement by ClubId
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        IEnumerable<SpecialRequirementViewModel> GetSpecialRequirement(int clubId);
        /// <summary>
        /// Get SpecialRequirement by ClubId with method Async
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        Task<IEnumerable<SpecialRequirementViewModel>> GetSpecialRequirementAsync(int ClubId);
    }
}
