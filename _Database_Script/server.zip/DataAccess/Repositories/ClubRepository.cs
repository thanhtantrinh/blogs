﻿using Dapper;
using DataAccess.Entities;
using DataAccess.EntitiesDataBase;
using DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper.Contrib.Extensions;
using System.Data.SqlClient;
using DataAccess.Utilities;

namespace DataAccess.Repositories
{
    public class ClubRepository : GenericRepository<ClubViewModel>, IClubRepository
    {
        IConnectionFactory _connectionFactory;
        public ClubRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }
        /// <summary>
        /// Get Club
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        public ClubViewModel GetClub(int ClubId)
        {
            var result = new ClubViewModel();
            using (var connection = _connectionFactory.GetConnection)
            {
                result = connection.Get<ClubViewModel>(ClubId);
            }
            return result;
        }

        public async Task<ClubViewModel> GetClubAsync(int clubId = 0)
        {

            try
            {
                var param = new DynamicParameters();
                param.Add("@ClubId", clubId);
                string sqlQuery = "select top 1 * from WSW_Club Where ID=@ClubId";
                using (var connection = _connectionFactory.GetConnection)
                {
                    return await SqlMapper.QueryFirstOrDefaultAsync<ClubViewModel>(connection, sqlQuery, param);
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetClubAsync at ClubRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        /// <summary>
        /// Get Club Detail Full Info
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public ClubDetailInfoViewModel GetClubDetailInfo(int clubId = 0)
        {
            var result = new ClubDetailInfoViewModel();
            try
            {
                if (clubId > 0)
                {
                    var param = new DynamicParameters();
                    param.Add("@ClubId", clubId);
                    string sqlQuery = String.Empty;
                    sqlQuery += "SELECT top 1 * from WSW_Club Where ID=@ClubId;";
                    sqlQuery += "SELECT top 100 * from WSW_ClubInfo Where ClubID=@ClubId;";
                    sqlQuery += "SELECT top 100 * from WSW_SeatingPref Where ClubID=@ClubId;";
                    sqlQuery += "SELECT top 100 * from WSW_SpecialRequirement Where ClubID=@ClubId;";

                    using (var connection = _connectionFactory.GetConnection)
                    {
                        var sqlResult = connection.QueryMultiple(sqlQuery, param);
                        IEnumerable<ClubViewModel> clubAsync = sqlResult.Read<ClubViewModel>();
                        IEnumerable<ClubInfoViewModel> clubInfo = sqlResult.Read<ClubInfoViewModel>();
                        IEnumerable<SeatingViewModel> seating = sqlResult.Read<SeatingViewModel>();
                        IEnumerable<SpecialRequirementViewModel> requirement = sqlResult.Read<SpecialRequirementViewModel>();
                        var club = clubAsync.FirstOrDefault();
                        if (club != null)
                        {
                            result.ID = club.ID;
                            result.Name = club.Name;
                            result.NickName = club.NickName;
                            result.Logo = club.Logo;
                            result.CreatedDate = club.CreatedDate;
                            result.UpdatedDate = club.UpdatedDate;
                            result.Style = club.Style;
                            result.PublicKey = club.PublicKey;
                            result.ListClubInfo = clubInfo.ToList();
                            result.ListSeatingPreference = seating.ToList();
                            result.ListSpecialRequirement = requirement.ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetClubDetailInfo at ClubRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            } 
            return result;
        }

    }
}
