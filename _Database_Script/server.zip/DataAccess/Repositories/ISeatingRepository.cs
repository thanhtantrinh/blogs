﻿using DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public interface ISeatingRepository : IGenericRepository<SeatingViewModel>
    {
        /// <summary>
        /// Get Seating Preference by ClubId
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        List<SeatingViewModel> GetSeatingPreference(int clubId);

        /// <summary>
        /// Get Seating Preference by ClubId with method Async
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        Task<IEnumerable<SeatingViewModel>> GetSeatingPreferenceAsync(int clubId);
    }
}
