﻿using DataAccess.Entities;
using DataAccess.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper.Contrib.Extensions;
using Dapper;
using DataAccess.Utilities;

namespace DataAccess.Repositories
{
    public class SpecialRequirementRepository : GenericRepository<SpecialRequirementViewModel>, ISpecialRequirementRepository
    {
        IConnectionFactory _connectionFactory;
        public SpecialRequirementRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }

        /// <summary>
        /// Get List SpecialRequirement by ClubId
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        public IEnumerable<SpecialRequirementViewModel> GetSpecialRequirement(int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (clubId > 0)
                    {
                        string sqlQuery = "SELECT * FROM WSW_SpecialRequirement WHERE ClubID=@ClubId";
                        var param = new DynamicParameters();
                        param.Add("@ClubId", clubId);
                        return conn.Query<SpecialRequirementViewModel>(sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSpecialRequirement at SeatingRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        /// <summary>
        /// Get List SpecialRequirement by ClubId
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<SpecialRequirementViewModel>> GetSpecialRequirementAsync(int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (clubId > 0)
                    {
                        string sqlQuery = "SELECT * FROM WSW_SpecialRequirement WHERE ClubID=@ClubId";
                        var param = new DynamicParameters();
                        param.Add("@ClubId", clubId);
                        return await conn.QueryAsync<SpecialRequirementViewModel>(sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSpecialRequirement at SeatingRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

    }
}
