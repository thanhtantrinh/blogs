﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{    
    using DataAccess.Entities;
    using DataAccess.EntitiesDataBase;
    using System.Data;

    public interface IMemberRepository : IGenericRepository<WSW_Member>
    {
        //Task<IEnumerable<Member>> GetMemberPaging(int pageIndex, int pageSize);
        /// <summary>
        /// Get Members In Group have been managed by Manager of Group (Member Manager)
        /// </summary>
        /// <param name="memberId">This is Member Id of the manager</param>
        /// <returns></returns>
        IEnumerable<MemberGroupViewModel> GetMemberInGroupOfManager(long memberId, int clubId);
        /// <summary>
        /// Count Member In Group By GroupId
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>
        Task<int> CountMemberOfGroupByGroupIdAsync(int groupId);
        /// <summary>
        /// Get Members In Group have been managed by Manager of Group (Member Manager)
        /// </summary>
        /// <param name="memberId"></param>
        /// <returns></returns>
        Task<IEnumerable<MemberGroupViewModel>> GetMemberInGroupOfManagerAsync(long managerId, int clubId);
        /// <summary>
        /// Get Member has registered In Group by memberNumber
        /// </summary>
        /// <param name="memberId">Username</param>
        /// <returns></returns>
        MemberGroupViewModel GetMemberInGroupByMemberNumber(string memberNumber,int clubId);
        Task<MemberGroupViewModel> GetMemberInGroupByMemberIdAsync(long memberId, int clubId);
        /// <summary>
        /// Get Member has registered In Group by memberNumber
        /// </summary>
        /// <param name="memberId">Username</param>
        /// <returns></returns>
        Task<MemberGroupViewModel> GetMemberInGroupByMemberNumberAsync(string memberNumber, int clubId);
        /// <summary>
        /// Save or create to register group
        /// </summary>
        /// <param name="tblData"></param>
        /// <param name="group"></param>
        /// <returns></returns>
        bool SaveMemberGroup(List<MemberGroupDetailBindingModel> model, GroupBindingModel group, out string errorDisplay);
    }
}
