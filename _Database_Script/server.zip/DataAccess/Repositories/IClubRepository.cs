﻿using DataAccess.Entities;
using DataAccess.EntitiesDataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    public interface IClubRepository : IGenericRepository<ClubViewModel>
    {
        /// <summary>
        /// Get Club with method Async
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        Task<ClubViewModel> GetClubAsync(int ClubId);
        /// <summary>
        /// Get Club from Table Club
        /// </summary>
        /// <param name="ClubId"></param>
        /// <returns></returns>
        ClubViewModel GetClub(int ClubId);
        /// <summary>
        /// Get Club Detail Full Info
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        ClubDetailInfoViewModel GetClubDetailInfo(int clubId);
    }
}
