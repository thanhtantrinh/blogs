﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    using Dapper;
    using DataAccess.Entities;
    using DataAccess.Infrastructure;
    using DataAccess.Utilities;

    public class SeatingRepository : GenericRepository<SeatingViewModel>, ISeatingRepository
    {
        IConnectionFactory _connectionFactory;
        public SeatingRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public List<SeatingViewModel> GetSeatingPreference(int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    var result = new List<SeatingViewModel>();
                    if (clubId > 0)
                    {
                        string sqlQuery = "SELECT * FROM WSW_SeatingPref WHERE ClubID=@ClubId";
                        var param = new DynamicParameters();
                        param.Add("@ClubId", clubId);
                        return conn.Query<SeatingViewModel>(sqlQuery, param).ToList();
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSeatingPreference at SeatingRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clubId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<SeatingViewModel>> GetSeatingPreferenceAsync(int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (clubId > 0)
                    {
                        string sqlQuery = "SELECT * FROM WSW_SeatingPref WHERE ClubID=@ClubId";
                        var param = new DynamicParameters();
                        param.Add("@ClubId", clubId);
                        return await conn.QueryAsync<SeatingViewModel>(sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, clubId);
                string subjectMail = "At GetSeatingPreferenceAsync at SeatingRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;

        }
    }
}
