﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repositories
{
    using Dapper;
    using DataAccess.Entities;
    using DataAccess.EntitiesDataBase;
    using DataAccess.Infrastructure;
    using DataAccess.Utilities;
    using DataAccess.ViewModel;
    using System.Data;

    public class MemberRepository : GenericRepository<WSW_Member>, IMemberRepository
    {
        IConnectionFactory _connectionFactory;
        public MemberRepository(IConnectionFactory connectionFactory)
        {
            _connectionFactory = connectionFactory;
        }
        /// <summary>
        /// Get list member In Group have been managed by Manager (Member Manager)
        /// </summary>
        /// <param name="managerId">This is manager Id of the manager</param>
        /// <returns></returns>
        public IEnumerable<MemberGroupViewModel> GetMemberInGroupOfManager(long managerId = 0, int clubId = 0)
        {
            try
            {
                if (managerId > 0)
                {
                    using (var conn = _connectionFactory.GetConnection)
                    {
                        var sqlQuery = "sp_WSW_GetMemberInGroupByManagerId";
                        var param = new DynamicParameters();
                        param.Add("@ManagerId", managerId);
                        if (clubId > 0)
                            param.Add("@ClubId", clubId);
                        return SqlMapper.Query<MemberGroupViewModel>(conn, sqlQuery, param, commandType: CommandType.StoredProcedure);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, managerId, clubId);
                string subjectMail = "At GetMemberInGroupOfManager at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }
        /// <summary>
        /// Count member in group
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>
        public async Task<int> CountMemberOfGroupByGroupIdAsync(int groupId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (groupId > 0)
                    {
                        var sqlQuery = "SELECT COUNT(*) FROM dbo.WSW_MemberGroup WHERE GroupID=@GroupId AND [Status]<>'Deleted'";
                        var param = new DynamicParameters();
                        param.Add("@GroupId", groupId);
                        return await SqlMapper.QuerySingleAsync<int>(conn, sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, groupId);
                string subjectMail = "At CountMemberOfGroupByGroupIdAsync at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return 0;
        }


        /// <summary>
        /// Get Members In Group have been managed by Manager (Member Manager)
        /// </summary>
        /// <param name="managerId">This is manager Id of the manager</param>
        /// <returns></returns>
        public async Task<IEnumerable<MemberGroupViewModel>> GetMemberInGroupOfManagerAsync(long managerId, int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (managerId > 0)
                    {
                        var sqlQuery = "sp_WSW_GetMemberInGroupByManagerId";
                        var param = new DynamicParameters();
                        param.Add("@ManagerId", managerId);
                        if (clubId > 0)
                        {
                            param.Add("@ClubId", clubId);
                        }
                        return await SqlMapper.QueryAsync<MemberGroupViewModel>(conn, sqlQuery, param, commandType: CommandType.StoredProcedure);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, managerId, clubId);
                string subjectMail = "At GetMemberInGroupOfManagerAsync at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        /// <summary>
        /// Get Member has registered In Group 
        /// </summary>
        /// <param name="memberNumber">MemberID</param>
        /// <returns></returns>
        public MemberGroupViewModel GetMemberInGroupByMemberId(string memberNumber)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (!String.IsNullOrEmpty(memberNumber))
                    {
                        var sqlQuery = "SELECT top 1 * FROM v_WSW_MemberInGroup WHERE MemberID=@MemberId";
                        var param = new DynamicParameters();
                        memberNumber = memberNumber.TrimEnd().TrimStart();
                        param.Add("@MemberId", memberNumber, DbType.String, null, 50);

                        var result = SqlMapper.Query<MemberGroupViewModel>(conn, sqlQuery, param).FirstOrDefault();
                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberNumber);
                string subjectMail = "At GetMemberInGroupByMemberId at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }
        public async Task<MemberGroupViewModel> GetMemberInGroupByMemberIdAsync(long memberId, int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (memberId > 0 && clubId > 0)
                    {
                        var sqlQuery = "SELECT top 1 * FROM v_WSW_MemberInGroup WHERE UserID=@MemberId and ClubID=@ClubId";
                        var param = new DynamicParameters();
                        param.Add("@MemberId", memberId);
                        param.Add("@ClubId", clubId);
                        return await SqlMapper.QueryFirstOrDefaultAsync<MemberGroupViewModel>(_connectionFactory.GetConnection, sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberId, clubId);
                string subjectMail = "At GetMemberInGroupByMemberIdAsync at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        public MemberGroupViewModel GetMemberInGroupByMemberNumber(string memberNumber, int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (!String.IsNullOrEmpty(memberNumber))
                    {
                        var sqlQuery = "SELECT * FROM v_WSW_MemberInGroup WHERE MemberID=@MemberId and ClubID=@ClubId";
                        var param = new DynamicParameters();
                        memberNumber = memberNumber.TrimEnd().TrimStart();
                        param.Add("@MemberId", memberNumber, DbType.String, null, 50);
                        param.Add("@ClubId", clubId);
                        return SqlMapper.QueryFirstOrDefault<MemberGroupViewModel>(conn, sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberNumber, clubId);
                string subjectMail = "At GetMemberInGroupByMemberIdAsync at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        public async Task<MemberGroupViewModel> GetMemberInGroupByMemberNumberAsync(string memberNumber, int clubId)
        {
            try
            {
                using (var conn = _connectionFactory.GetConnection)
                {
                    if (!String.IsNullOrEmpty(memberNumber))
                    {
                        var sqlQuery = "SELECT * FROM v_WSW_MemberInGroup WHERE MemberID=@MemberId AND ClubID=@ClubId";
                        var param = new DynamicParameters();
                        memberNumber = memberNumber.TrimEnd().TrimStart();
                        param.Add("@MemberId", memberNumber, DbType.String, null, 50);
                        param.Add("@ClubId", clubId);
                        return await SqlMapper.QuerySingleAsync<MemberGroupViewModel>(conn, sqlQuery, param);
                    }
                }
            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex, memberNumber, clubId);
                string subjectMail = "At GetMemberInGroupByMemberNumberAsync at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();
            }
            return null;
        }

        /// <summary>
        /// Store Member to update, create
        /// </summary>
        /// <param name="model"></param>
        /// <param name="group"></param>
        /// <returns></returns>
        public bool SaveMemberGroup(List<MemberGroupDetailBindingModel> model, GroupBindingModel group, out string errorDisplay)
        {
            errorDisplay = string.Empty;
            try
            {
                DataTable tblMember = new DataTable();
                tblMember.Columns.AddRange(new DataColumn[9] {
                        new DataColumn("MemberGroupID", typeof(int)),
                        new DataColumn("UserId",typeof(int)),
                        new DataColumn("MemberNumber",typeof(string)),
                        new DataColumn("SpecialRequirementID",typeof(int)),
                        new DataColumn("IsGroupManager",typeof(bool)),
                        new DataColumn("Priority",typeof(int)),
                        new DataColumn("Attachment",typeof(string)),
                        new DataColumn("OtherRequirement",typeof(string)),
                        new DataColumn("GroupID",typeof(int))
                });
                foreach (var item in model)
                {

                    string otherRequirement = string.IsNullOrEmpty(item.OtherRequirement) ? "" : item.OtherRequirement;
                    string attachment = string.IsNullOrEmpty(item.Attachment) ? "" : item.Attachment;

                    tblMember.Rows.Add(
                        item.MemberGroupID,
                        item.UserID,
                        "",
                        item.SpecialRequirementID,
                        item.IsGroupManager,
                        item.Priority,
                        attachment,
                        otherRequirement,
                        group.GroupID
                    );
                }
                long managerId = model.FirstOrDefault(m => m.IsGroupManager == true).UserID;
                var param = new DynamicParameters();
                param.Add("@ManagerId", managerId);
                param.Add("@ClubId", group.ClubID);
                param.Add("@GroupStatus", group.GroupStatus);
                param.Add("@GroupSeatingPrefID", group.SeatingID);
                param.Add("@GroupType", group.GroupType);
                param.Add("@GroupNote", "");
                param.Add("@GroupMember", tblMember.AsTableValuedParameter("dbo.WSW_UDT_MemberOfGroup"));
                param.Add("@ErrorDisplay", dbType: DbType.String, direction: ParameterDirection.Output, size: 500);
                var sqlQuery = "sp_WSW_StoreMemberInGroup";

                using (var conn = _connectionFactory.GetConnection)
                {
                    var result = SqlMapper.Query(conn, sqlQuery, param, commandType: CommandType.StoredProcedure);
                    errorDisplay = param.Get<string>("@ErrorDisplay");
                    if (String.IsNullOrEmpty(errorDisplay))
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                string errorContent = CommonUtilities.Parameters2ErrorString(ex);
                string subjectMail = "At SaveMemberGroup at MemberRepository at DataAccess.Repositories";
                EmailUtility.SendErrorEmail(subjectMail, errorContent);
            }
            finally
            {
                _connectionFactory.GetConnection.Close();                
            }
            return false;
        }


    }
}
