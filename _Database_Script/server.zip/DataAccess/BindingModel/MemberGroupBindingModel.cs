﻿using System;

namespace DataAccess
{
    using System.ComponentModel.DataAnnotations;
    /// <summary>
    /// 
    /// </summary>
    public class MemberGroupDetailBindingModel
    {
        /// <summary>
        /// ID is key in MemberGroup table
        /// </summary>
        public long MemberGroupID { get; set; }

        #region Info Member common in Group
        /// <summary>
        /// ID is key in Member table
        /// </summary>
        [Required]
        [Display(Name = "Member ID")]
        public long UserID { get; set; }

        [Required]
        [Display(Name = "Member Number")]
        public string MemberNumber { get; set; }
        #endregion

        #region Info Member details in the group
        /// <summary>
        /// ID for Special Requirements
        /// </summary>
        public int SpecialRequirementID { get; set; }
        /// <summary>
        /// Do you have Group Manager
        /// </summary>        
        public bool IsGroupManager { get; set; }
        /// <summary>
        /// Value for sort
        /// </summary>
        [Required]
        public int Priority { get; set; }
        /// <summary>
        /// path for the attachment file
        /// </summary>
        public string Attachment { get; set; }
        /// <summary>
        /// To store for the other requirement 
        /// </summary>
        public string OtherRequirement { get; set; }
        #endregion
    }
    public class GroupBindingModel
    {

        #region Info Group Detail
                /// <summary>
        /// Group Id
        /// </summary>
        public int GroupID { get; set; }
        /// <summary>
        /// Group Name
        /// </summary>
        public string GroupName { get; set; }
        [Required]
        [Display(Name = "Group Status")]
        /// <summary>
        /// Group Status Pending, Step1, Step2, Step3 or Submited
        /// </summary>
        public string GroupStatus { get; set; }
        /// <summary>
        /// GroupType Single or Group
        /// </summary>
        [Required]
        [Display(Name = "Group Type")]
        public string GroupType { get; set; }
        /// <summary>
        /// ID for Seating Preference
        /// </summary>        
        [Display(Name = "Seating preference")]
        public int SeatingID { get; set; }

        /// <summary>
        /// Club Id
        /// </summary>
        [Required]
        [Display(Name = "Club Id")]
        public int ClubID { get; set; }

        #endregion
        public GroupBindingModel()
        {

        }
    }

    /// <summary>
    /// MemberGroupBindingModel to add to Member Group
    /// </summary>
    //public class MemberGroupBindingModel
    //{
    //    /// <summary>
    //    /// This is Username
    //    /// </summary>        
    //    [Required]
    //    [Display(Name = "Member Number")]
    //    public string MemberId { get; set; }
    //    /// <summary>
    //    /// This is FirstName
    //    /// </summary>        
    //    //[Required]
    //    [Display(Name = "Given Name")]
    //    public string GivenName { get; set; }
    //    /// <summary>
    //    /// This is Lastname
    //    /// </summary>
    //    //[Required]
    //    [Display(Name = "Surname")]
    //    public string SurName { get; set; }
    //}
}
